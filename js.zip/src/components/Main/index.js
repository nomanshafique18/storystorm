import React, { useState, useEffect } from "react";

const unicorns = [
  {
    name: "bob",
    age: "30",
    color: "red",
    favoriteFruitId: 1,
    active: true,
  },
  {
    name: "john",
    age: "20",
    color: "blue",
    favoriteFruitId: 2,
    active: false,
  },
  {
    name: "jane",
    age: "25",
    color: "black",
    favoriteFruitId: 1,
    active: true,
  },
  {
    name: "doge",
    age: "21",
    color: "yellow",

    active: true,
  },
  {
    name: "cate",
    age: "33",
    color: "white",
    favoriteFruitId: 1,
    active: true,
  },
].sort((a, b)=>{return a.age - b.age});
const fruits = [
  { id: 1, name: "apple" },
  { id: 2, name: "watermelon" },
];

const Main = () => {
  return (
    <>
      <div className="container-fluid  p-3">
        {unicorns.map((item) => {
          if (item.active && item.color !== "black") {
            if(item.name==="doge"){
              item[`muchWow`]=true
              item[`suchFat`]=true
              item[`lovesCate`]=false
            }
            return (
              <>
                <div class="card">
                  <div class="card-header">{item.name}</div>
                  <div class="card-body">
                    <blockquote class="blockquote mb-0">
                      {fruits.map((i) => {
                        if (item.favoriteFruitId === i.id) {
                          return (<p>{i.name}</p>)
                        }
                      })}
                    </blockquote>
                  </div>
                </div>
              </>
            );
          
        }
        })}
      </div>
      
    </>
  );
};

export default Main;
