import React from 'react'
import "./footer.css"



export default function Footer() {

	return(
		<>

		<div className="footer">
		

		

		</div>
		<p className="footer-text">
		©2021 All Rights Reserved. Ass@no-2
		</p>
		</>
		)
	}
